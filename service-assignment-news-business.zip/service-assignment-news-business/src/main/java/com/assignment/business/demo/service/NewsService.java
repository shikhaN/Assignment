package com.assignment.business.demo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.assignment.business.demo.model.Article;
import com.assignment.business.demo.model.ArticlesList;
import com.assignment.business.demo.model.NewsModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;

@Service
public class NewsService {

	Logger logger = LoggerFactory.getLogger(NewsService.class);
	@Value("${api-url}")
	String uri;

	@Autowired
	RestTemplate restTemplate;

	public ArticlesList getNews(int filterCount, String apikey) throws JsonMappingException, JsonProcessingException {

		logger.info("*** Inside getNews Service ***");
		RestTemplate restTemplate = new RestTemplate();

		String apiUri = uri + apikey;

		String result = restTemplate.getForObject(apiUri, String.class);

		ObjectMapper mapper = new ObjectMapper();
		NewsModel readValue = mapper.readValue(result, NewsModel.class);
		ArrayList<Article> articles = new ArrayList<>();
		ArticlesList articlesList = new ArticlesList();
		int articlesSize = readValue.getArticles().size();
		if (articlesSize > filterCount) {
			articlesSize = filterCount;
		}
		Article article = new Article();
		for (int i = 0; i < articlesSize; i++) {

			article.setAuthor(readValue.getArticles().get(i).getAuthor());
			article.setSource(readValue.getArticles().get(i).getSource());
			article.setDescription(readValue.getArticles().get(i).getDescription());
			article.setPublishedAt(readValue.getArticles().get(i).getPublishedAt());
			article.setContent(readValue.getArticles().get(i).getContent());
			article.setTitle(readValue.getArticles().get(i).getTitle());
			article.setUrl(readValue.getArticles().get(i).getUrl());
			article.setUrlToImage(readValue.getArticles().get(i).getUrlToImage());
			articles.add(article);
		}

		articlesList.setArticles(articles);
		logger.info("*** Service getNews Returning object Articles***");
		return articlesList;
	}

}
