package com.assignment.business.demo.model;

import lombok.Data;

@Data
public class Source {

	String id;
	String name;
}
