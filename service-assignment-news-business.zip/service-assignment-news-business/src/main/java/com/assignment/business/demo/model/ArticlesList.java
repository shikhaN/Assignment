package com.assignment.business.demo.model;

import java.util.ArrayList;

import lombok.Data;

@Data
public class ArticlesList {
	ArrayList<Article> articles;
}
