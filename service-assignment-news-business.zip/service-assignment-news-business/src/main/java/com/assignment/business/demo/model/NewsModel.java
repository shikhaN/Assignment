package com.assignment.business.demo.model;

import lombok.Data;

import java.util.ArrayList;

@Data
public class NewsModel {
	String status;
	int totalResults;
	ArrayList<Article> articles;
}
