package com.assignment.business.demo.controller;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.business.demo.model.Article;
import com.assignment.business.demo.model.ArticlesList;
import com.assignment.business.demo.model.NewsModel;
import com.assignment.business.demo.service.NewsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NewsController {

	Logger logger = LoggerFactory.getLogger(NewsController.class);
	@Autowired
	NewsService service;

	/*
	 * 
	 * curl --location --request GET
	 * 'http://localhost:8082/getNews?filterCount=5&apiKey=
	 * 6f6b892c4a95492eb77497716fc7d548' \ --header 'Content-Type: application/json'
	 * \ --data-raw ''
	 * 
	 */
	@GetMapping(value = "/getNews", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArticlesList> getNews(@RequestParam int filterCount, @RequestParam String apiKey)
			throws JsonMappingException, JsonProcessingException {

		logger.info("*** Inside getNews Controller ***");
		ArticlesList result = service.getNews(filterCount, apiKey);

		return ResponseEntity.ok().body(result);

	}
}
