package com.assignment.business.demo.model;

import java.util.Date;

import lombok.Data;

@Data
public class Article {
	Source source;
	String author;
	String title;
	String description;
	String url;
	String urlToImage;
	Date publishedAt;
	String content;

}
